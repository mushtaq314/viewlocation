import tkinter as tk
from tkinter import messagebox
import pyautogui
import cv2
import numpy as np
from PIL import ImageGrab
import threading
import datetime

recording = False
paused = False
out = None

def record_screen():
    global recording, paused, out
    screen_size = pyautogui.size()

    # Generate a new filename for every new recording
    filename = datetime.datetime.now().strftime("recording_%Y%m%d_%H%M%S.avi")
    fourcc = cv2.VideoWriter_fourcc(*"XVID")
    out = cv2.VideoWriter(filename, fourcc, 10.0, screen_size)

    while recording:
        if not paused:
            img = ImageGrab.grab()
            frame = np.array(img)
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            out.write(frame)

    if out:
        out.release()
        out = None

def start_recording():
    global recording, paused
    if recording:
        messagebox.showinfo("Already Recording", "Recording is already in progress.")
        return
    recording = True
    paused = False
    status_label.config(text="🔴 Recording...")
    threading.Thread(target=record_screen, daemon=True).start()

def pause_recording():
    global paused
    if not recording:
        messagebox.showwarning("Not Recording", "Start recording first.")
    elif paused:
        messagebox.showinfo("Already Paused", "Recording is already paused.")
    else:
        paused = True
        status_label.config(text="⏸️ Paused")

def resume_recording():
    global paused
    if not recording:
        messagebox.showwarning("Not Recording", "Start recording first.")
    elif not paused:
        messagebox.showinfo("Already Running", "Recording is already running.")
    else:
        paused = False
        status_label.config(text="🔴 Recording...")

def stop_recording():
    global recording, paused, out
    if recording:
        recording = False
        paused = False
        status_label.config(text="✅ Recording Stopped")
        messagebox.showinfo("Screen Recorder", "Recording saved successfully!")
    else:
        messagebox.showwarning("Not Recording", "You need to start recording first.")

def exit_app():
    if recording:
        stop_recording()
    root.destroy()

# GUI setup
root = tk.Tk()
root.title("🎥 Screen Recorder")
root.geometry("300x370")
root.resizable(False, False)
root.configure(bg="#f7f7f7")

tk.Label(root, text="🎬 Screen Recorder", font=("Arial", 16, "bold"), bg="#f7f7f7").pack(pady=15)
status_label = tk.Label(root, text="🟢 Ready", font=("Arial", 12), fg="green", bg="#f7f7f7")
status_label.pack(pady=5)

# Button style
btn_style = {
    "bg": "#e0e0e0",
    "fg": "#000000",
    "font": ("Arial", 10),
    "width": 22,
    "height": 1,
    "bd": 1,
    "relief": "groove",
    "activebackground": "#d0d0d0"
}

# Buttons
tk.Button(root, text="▶️ Start Recording", command=start_recording, **btn_style).pack(pady=6)
tk.Button(root, text="⏸️ Pause", command=pause_recording, **btn_style).pack(pady=6)
tk.Button(root, text="⏯️ Resume", command=resume_recording, **btn_style).pack(pady=6)
tk.Button(root, text="⏹️ Stop Recording", command=stop_recording, **btn_style).pack(pady=6)
tk.Button(root, text="❌ Exit", command=exit_app, **btn_style).pack(pady=12)

root.mainloop()
